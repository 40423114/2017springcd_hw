for i in range(1000000):
    def f(x):
        pass

