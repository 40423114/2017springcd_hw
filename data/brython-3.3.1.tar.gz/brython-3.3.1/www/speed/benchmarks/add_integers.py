a, b, c = 1, 2, 3
for i in range(1000000):
    a + b + c

