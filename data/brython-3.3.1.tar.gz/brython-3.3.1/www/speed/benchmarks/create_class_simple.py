for i in range(10000):
    
    class A:
        pass

