d={}
for _i in range(100000):
    d[_i]=_i
