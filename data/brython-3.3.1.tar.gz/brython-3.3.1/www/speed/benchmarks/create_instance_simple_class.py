class A:
    pass

for i in range(10000):
    
    A()
