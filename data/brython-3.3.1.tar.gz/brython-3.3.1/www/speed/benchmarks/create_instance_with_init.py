class A:
    def __init__(self, x):
        self.x = x

for i in range(10000):
    
    A(i)
