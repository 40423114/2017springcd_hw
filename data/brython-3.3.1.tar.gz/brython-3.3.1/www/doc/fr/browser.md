Le paquetage **browser** définit les noms et les modules intégrés spécifiques à Brython

**browser**.`alert(`_message_`)`
> une fonction qui affiche le _message_ dans une fenêtre. Retourne la valeur `None`

**browser**.`confirm(`_message_`)`
> une fonction qui affiche le _message_ dans une fenêtre et deux boutons de réponse (ok/annuler). Retourne `True` si ok, `False` sinon

**browser**.`console`
> un objet avec des méthods pour interagir avec la console du navigateur. Son interface est propre à chaque navigateur. Il expose au moins la méthode `log(msg)`, qui imprime le message _msg_ dans la console

**browser**.`document`
> un objet représentant le document HTML présenté dans le navigateur. L'interface de ce document est décrite dans la section "Interface avec le navigateur"

**browser**.`DOMEvent`
> la classe des événements DOM

**browser**.`DOMNode`
> la classe des noeuds DOM

**browser**.`load(`_script\_url[,noms]_`)`
> Fonction pour charger le script Javascript à l'adresse _script\_url_ et 
> insérer la liste de _noms_ dans l'espace de noms du programme.

> Cette fonction utilise un appel Ajax bloquant. Il faut l'utiliser quand on
> ne peut pas insérer la librairie Javascript dans la page html par
> `<script src="prog.js"></script>`. 

> Par exemple, le module **jqueryui** de la bibliothèque standard Brython
> fournit une interface avec la librairie Javascript jQueryUI. Si on écrit un
> script Brython qui utilise ce module, on fait simplement `import jqueryui`
> sans insérer les librairies Javascript dans la page. C'est le module 
> **jqueryui** qui les charge, en utilisant cette fonction `load()`

**browser**.`prompt(`_message[,defaut]_`)`
> une fonction qui affiche le _message_ dans une fenêtre et une zone de saisie. Retourne la valeur saisie ; si aucune valeur n'est saisie, retourne _defaut_, ou la chaine vide si _defaut_ n'est pas fourni

**browser**.`window`
> un objet représentant la fenêtre du navigateur
