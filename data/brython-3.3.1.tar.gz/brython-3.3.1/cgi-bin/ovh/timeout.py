#!/usr/bin/python
# -*- coding: utf-8 -*-


from time import sleep


print('Content-type: text/plain\n\n')
sleep(10)
print('script cgi with GET')
